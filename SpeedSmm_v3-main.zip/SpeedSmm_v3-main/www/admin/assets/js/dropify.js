// npm package: dropify
// github link: https://github.com/JeremyFagis/dropify

$(function() {
  'use strict';

  $('#myDropify').dropify();

});